# Based-ACER-Nitro-Personal-DB

This is the connection to the XAMPP that will need tranfer the updated to honniel's branch

Counter - 1
