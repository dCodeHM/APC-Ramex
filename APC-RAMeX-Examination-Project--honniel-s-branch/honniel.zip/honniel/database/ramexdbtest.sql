-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 21, 2024 at 04:35 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ramexdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `account_id` int(11) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `pwd` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `role` varchar(60) NOT NULL DEFAULT 'Unassigned',
  `program_id` int(11) NOT NULL,
  `role_request` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`account_id`, `user_email`, `pwd`, `date_created`, `first_name`, `last_name`, `role`, `program_id`, `role_request`) VALUES
(1, 'hmanes@student.apc.edu.ph', '123', '2024-04-15 07:18:46', 'Honniel', 'Manes', 'Unassigned', 0, NULL),
(2, 'cagonzales@student.apc.edu.ph', 'cagmyloves', '2024-04-15 07:21:16', 'Charmie', 'Gonzales', 'Unassigned', 0, NULL),
(3, 'einsteinyong@apc.edu.ph', 'APC123', '2024-04-15 07:21:16', 'Einstein', 'Yong', 'Professor', 0, NULL),
(4, 'sergioperuda@apc.edu.ph', 'sandarating', '2024-04-15 07:21:16', 'Sergio', 'Peruda', 'Program Director', 0, NULL),
(5, 'lcdejesus@apc.edu.ph', 'gamer123', '2024-04-15 07:21:16', 'Luigi', 'De Jesus', 'Admin', 0, NULL),
(6, 'Lerbron@apc.edu.ph', 'yes', '2024-04-15 08:52:43', 'Lebron', 'James', 'Unassigned', 0, NULL),
(7, 'steph@gmail.com', '#Manes123', '2024-04-15 09:18:09', 'Steph', 'Curry', 'Unassigned', 0, NULL),
(8, '123@gmail.com', 'manes123', '2024-04-15 09:49:34', 'manes', 'manes', 'Unassigned', 0, NULL),
(9, 'nen-utibovo99@apc.edu.ph', '123', '2024-04-17 23:50:58', 'Nen', 'Utiv', 'Unassigned', 0, NULL),
(10, 'fewe-xecibu94@apc.edu.ph', 'hfdhd', '2024-04-17 23:50:58', 'Fewe', 'Xecibu', 'Unassigned', 0, NULL),
(11, 'worugo-dayu49@apc.edu.ph', 'asgdgdg', '2024-04-17 23:50:58', 'Worugo', 'Dayu', 'Unassigned', 0, NULL),
(12, 'fofejen-ivi3@apc.edu.ph', 'dnffg', '2024-04-17 23:50:58', 'Fofejen', 'Ivi', 'Unassigned', 0, NULL),
(13, 'teno_jaluze47@apc.edu.ph', 'tecbcb', '2024-04-17 23:50:58', 'Teno', 'Jaluze', 'Unassigned', 0, NULL),
(14, 'baduci_mopu33@apc.edu.ph', 'gehc', '2024-04-17 23:50:58', 'Baduci', 'Mopu', 'Unassigned', 0, NULL),
(15, 'dov_ikoxewu41@apc.edu.ph', 'ehesc', '2024-04-17 23:50:58', 'Dov', 'Ikoxewu', 'Unassigned', 0, NULL),
(16, 'pile-siwodo60@apc.edu.ph', 'hrhxf', '2024-04-17 23:50:58', 'PIle', 'Siwodo', 'Unassigned', 0, NULL),
(17, 'nuxag_uhava37@apc.edu.ph', 'qye', '2024-04-17 23:50:58', 'Nuxag', 'Uhava', 'Unassigned', 0, NULL),
(18, 'duw-uxeyoxu99@apc.edu.ph', 'qeeye', '2024-04-17 23:50:58', 'Duw', 'Uxeyoxu', 'Unassigned', 0, NULL),
(19, 'dacup-ezuju22@apc.edu.ph', 'adhe', '2024-04-17 23:50:58', 'Dacup', 'Ezuju', 'Unassigned', 0, NULL),
(20, 'fetagip_exa51@apc.edu.ph', 'Fetagip', '2024-04-17 23:50:58', 'Hetagip', 'Exa', 'Unassigned', 0, NULL),
(21, 'hen-agecihe6@apc.edu.ph', 'haaddg', '2024-04-17 23:50:58', 'Hen', 'Agecihe', 'Unassigned', 0, NULL),
(22, 'mos-ivezuro75@apc.edu.ph', 'gadhe', '2024-04-17 23:50:58', 'Mos', 'Ivezuro', 'Unassigned', 0, NULL),
(23, 'cep_ogataya70@apc.edu.ph', 'gead', '2024-04-17 23:50:58', 'CCep', 'Ogataya', 'Unassigned', 0, NULL),
(24, 'cala_yujiki4@apc.edu.ph', 'hsshf', '2024-04-17 23:50:58', 'Cala', 'Yukizi', 'Unassigned', 0, NULL),
(25, 'mubeli-rihe4@apc.edu.ph', 'hsf', '2024-04-17 23:50:58', 'Mubeli', 'Rihe', 'Unassigned', 0, NULL),
(26, 'luxupu-noso90@apc.edu.ph', 'sgd', '2024-04-17 23:50:58', 'Luxupu', 'Noso', 'Unassigned', 0, NULL),
(27, 'voki_yuvaxu1@apc.edu.ph', 'asd', '2024-04-17 23:50:58', 'Voki', 'Yuvaxu', 'Unassigned', 0, NULL),
(28, 'fesij_arele63@apc.edu.ph', 'qwe', '2024-04-17 23:50:58', 'Fesij', 'Arele', 'Unassigned', 0, NULL),
(29, 'kuhevur-ufu46@apc.edu.ph', 'asd', '2024-04-17 23:50:58', 'Kehevur', 'Ufu', 'Unassigned', 0, NULL),
(30, 'ruheja_recu94@apc.edu.ph', 'www', '2024-04-17 23:50:58', 'Ruheja', 'Recu', 'Unassigned', 0, NULL),
(31, 'vefadik-ere33@apc.edu.ph', 'qqqw', '2024-04-17 23:50:58', 'Vefadik', 'Ere', 'Unassigned', 0, NULL),
(32, 'nedix-afidi79@apc.edu.ph', '123', '2024-04-17 23:50:58', 'Nedix', 'Afidi', 'Unassigned', 0, NULL),
(33, 'muveb_isili25@apc.edu.ph', '6969', '2024-04-17 23:50:58', 'Muveb', 'Isili', 'Admin', 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `Category_ID` int(11) NOT NULL,
  `Category_Name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`Category_ID`, `Category_Name`) VALUES
(1, 'Category A '),
(2, 'Category B');

-- --------------------------------------------------------

--
-- Table structure for table `exam_library`
--

CREATE TABLE `exam_library` (
  `exam_id` int(10) NOT NULL,
  `exam_name` varchar(255) NOT NULL,
  `question_id` int(10) NOT NULL,
  `folder_id` int(10) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `exam_upload`
--

CREATE TABLE `exam_upload` (
  `upload_id` int(10) NOT NULL,
  `filename` blob NOT NULL,
  `exam_id` int(10) NOT NULL,
  `folder_id` int(10) NOT NULL,
  `upload_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `notification_id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `message` varchar(255) NOT NULL,
  `dateT` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Product_ID` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Product_ID`, `product_name`, `category_id`) VALUES
(1, 'Product A1', 1),
(2, 'Product A2', 1),
(3, 'Product B1', 2),
(4, 'QWE', 1),
(5, 'QWE', 1),
(6, 'QWE', 1),
(7, 'QWE', 1),
(8, 'qwe', 1);

-- --------------------------------------------------------

--
-- Table structure for table `prof_course_subject`
--

CREATE TABLE `prof_course_subject` (
  `course_subject_id` int(10) NOT NULL,
  `course_subject` varchar(255) NOT NULL,
  `course_code` varchar(255) NOT NULL,
  `course_syllabus_id` int(10) DEFAULT NULL,
  `course_topic_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `prof_course_subject`
--

INSERT INTO `prof_course_subject` (`course_subject_id`, `course_subject`, `course_code`, `course_syllabus_id`, `course_topic_id`) VALUES
(1, 'Computer Engineering', 'CPEDRAFT', 0, 0),
(2, 'sample subject', 'sample code 1', 0, 0),
(3, 'blablabla', '23123123', 0, 0),
(4, 'course3', 'coursecode3', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `prof_course_topic`
--

CREATE TABLE `prof_course_topic` (
  `course_topic_id` int(10) NOT NULL,
  `course_topics` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `program_list`
--

CREATE TABLE `program_list` (
  `program_id` int(10) NOT NULL,
  `program_name` varchar(60) NOT NULL,
  `course_ID` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `program_list`
--

INSERT INTO `program_list` (`program_id`, `program_name`, `course_ID`) VALUES
(2, 'Computer Engineering', '1'),
(3, 'Electronics Engineering', '2'),
(4, 'Civil Engineering', '3');

-- --------------------------------------------------------

--
-- Table structure for table `question_choices`
--

CREATE TABLE `question_choices` (
  `answer_id` int(10) NOT NULL,
  `answer_text` varchar(255) NOT NULL,
  `answer_image` blob NOT NULL,
  `choices` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `question_library`
--

CREATE TABLE `question_library` (
  `question_id` int(10) NOT NULL,
  `question_text` varchar(255) DEFAULT NULL,
  `question_image` blob NOT NULL,
  `answer_id` int(10) NOT NULL,
  `clo_id` int(10) NOT NULL,
  `difficulty` varchar(30) NOT NULL,
  `question_points` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `role` varchar(50) NOT NULL,
  `role_description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`role`, `role_description`) VALUES
('Admin', 'Has access to the Student Assessment, Course Assessment, and Exam Maker.'),
('Professor', 'Has access to the Student Assessment and Exam Maker'),
('Program Director', 'Has access to the Student Assessment, Course Assessment, and Exam Maker.'),
('Unassigned', 'Has no access');

-- --------------------------------------------------------

--
-- Table structure for table `role_request`
--

CREATE TABLE `role_request` (
  `request_id` int(10) NOT NULL,
  `account_id` int(10) NOT NULL,
  `requestedRole` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `stud_name` varchar(191) NOT NULL,
  `stud_class` varchar(100) NOT NULL,
  `stud_phone` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `stud_name`, `stud_class`, `stud_phone`) VALUES
(1, 'qwe', 'BOBO qwe', 'qwe'),
(2, 'qweqwe', 'qweqwe', 'qweqwe');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(10) NOT NULL,
  `account_id` int(10) NOT NULL,
  `role` int(10) NOT NULL,
  `program_id` int(10) NOT NULL,
  `role_request` varchar(100) DEFAULT 'No Request'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`account_id`),
  ADD UNIQUE KEY `user_email` (`user_email`),
  ADD KEY `program` (`program_id`),
  ADD KEY `role` (`role`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`Category_ID`);

--
-- Indexes for table `exam_library`
--
ALTER TABLE `exam_library`
  ADD PRIMARY KEY (`exam_id`);

--
-- Indexes for table `exam_upload`
--
ALTER TABLE `exam_upload`
  ADD PRIMARY KEY (`upload_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `connection for user` (`user_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`Product_ID`),
  ADD KEY `Category_constraint` (`category_id`);

--
-- Indexes for table `prof_course_subject`
--
ALTER TABLE `prof_course_subject`
  ADD PRIMARY KEY (`course_subject_id`);

--
-- Indexes for table `prof_course_topic`
--
ALTER TABLE `prof_course_topic`
  ADD PRIMARY KEY (`course_topic_id`);

--
-- Indexes for table `program_list`
--
ALTER TABLE `program_list`
  ADD PRIMARY KEY (`program_id`);

--
-- Indexes for table `question_choices`
--
ALTER TABLE `question_choices`
  ADD PRIMARY KEY (`answer_id`);

--
-- Indexes for table `question_library`
--
ALTER TABLE `question_library`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`role`);

--
-- Indexes for table `role_request`
--
ALTER TABLE `role_request`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `requestedRole` (`requestedRole`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `account_id` (`account_id`),
  ADD KEY `connection for program list` (`program_id`),
  ADD KEY `role` (`role`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `account_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `Category_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `exam_library`
--
ALTER TABLE `exam_library`
  MODIFY `exam_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `notification_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `Product_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `prof_course_subject`
--
ALTER TABLE `prof_course_subject`
  MODIFY `course_subject_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `prof_course_topic`
--
ALTER TABLE `prof_course_topic`
  MODIFY `course_topic_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `program_list`
--
ALTER TABLE `program_list`
  MODIFY `program_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `question_library`
--
ALTER TABLE `question_library`
  MODIFY `question_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `role_request`
--
ALTER TABLE `role_request`
  MODIFY `request_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `account`
--
ALTER TABLE `account`
  ADD CONSTRAINT `roles` FOREIGN KEY (`role`) REFERENCES `role` (`role`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `notification`
--
ALTER TABLE `notification`
  ADD CONSTRAINT `connection for user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `Category_constraint` FOREIGN KEY (`category_id`) REFERENCES `category` (`Category_ID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
