<?php
session_start();
require('database/connect.php');
if (!isset($_SESSION['account_id'])) {
    // Redirect to the login page if the user is not logged in
    echo '<script>alert("User is not logged in, directing to login page.")</script>';
    echo "<script> window.location.assign('login.php'); </script>";
    exit();
}


$account_id = $_SESSION['account_id'];


// Display the user-specific information
$sql = "SELECT * FROM account WHERE account_id = $account_id";
$result = mysqli_query($conn, $sql); // Replace with data from the database
if ($result) {
    $row = mysqli_fetch_array($result);
    $user_email = $row['user_email'];
    $pwd = $row['pwd'];
    $first_name = $row['first_name'];
    $last_name = $row['last_name'];
    $role = $row['role'];
}
?>
 <?php include('topnavAdmin.php'); ?>
<!DOCTYPE html>


<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="author" content="APC AcademX">
    <title>APC AcademX | User Settings</title>
    <link rel="stylesheet" href="./css/adminstyle.css">
    <script src="https://kit.fontawesome.com/e85940e9f2.js" crossorigin="anonymous"></script>
</head>

<body>
    <!-- body -->
    <div class="column">

        <div class="left">

            <div class="sidenav" id="bar">

                <div class="back">
                    <a href="#">
                        <img src="./img/Back Logo.png">
                    </a>
                </div>

                <div class="help">
                    <a href="#">
                        <img src="./img/Help.png">
                    </a>
                </div>

            </div>
        </div>

        <div class="mid">

            <div class="midnav">

                <div class="midhead">
                    <p> Settings </p>
                </div>

                <div class="line">
                </div>

                <div>
                    <a href="usersettings.php" class="midbutton active">
                        <p> User Settings </p>
                    </a>
                </div>

                <div>
                    <a href="adminset.php" class="midbutton">
                        <p> Admin Settings </p>
                    </a>
                </div>

                <div>
                    <a href="programlist.php" class="midbutton">
                        <p> Program List </p>
                    </a>
                </div>

            </div>


        </div>

        <div class="right">

            <div class="container">

                <div class="righthead">

                    <div class="adminicon">
                        <img lass="iconadmin" src="./img/user.png" width="70%">
                    </div>

                    <div class="userhead">
                        <p> User Settings</p>
                    </div>

                    <div class="search">
                        <div>
                            <input type="text" class="searchbar">
                        </div>

                        <div class="searchicon">
                            <i class="fa-solid fa-magnifying-glass"></i>
                        </div>
                    </div>
                </div>

                <div class="userline">
                    <div class="table">
                        <div class="tablecontent">
                            <p style="margin-left: 10 px;">
                                School Role
                            </p>

                            <div class="adassign">
                                <p>
                                    Professor
                                </p>

                            </div>
                            <div class="adrequest">
                                <p> Request </p>
                            </div>
                        </div>

                        <div class="tablecontent">
                            <p style="margin-left: 10 px;">
                                First Name
                            </p>

                            <div class="adassign">
                                <p>
                                    Paulo
                                </p>
                            </div>
                        </div>

                        <div class="tablecontent">
                            <p style="margin-left: 10 px;">
                                Last Name
                            </p>

                            <div class="adassign">
                                <p>
                                    Cosio
                                </p>
                            </div>
                        </div>

                        <div class="tablecontent">
                            <p style="margin-left: 10 px;">
                                Email Address
                            </p>

                            <div class="adassign">
                                <p>
                                    pcausio@apc.edu.ph
                                </p>
                            </div>
                        </div>

                        <div class="tablecontent">
                            <p style="margin-left: 10 px;">
                                Password
                            </p>
                            <div class="adassign">
                                <p>
                                    sircaosiobecrazy4
                                </p>
                            </div>

                            <p>
                                change
                            </p>
                        </div>

                    </div>
                </div>


                <div class="info">
                    <div class="rolesinfo">
                        <a href="#"><i class="fa-solid fa-circle-info"></i> Roles Information </a>
                    </div>
                </div>
            </div>

        </div>
        <!--sheesh
-->
</body>

</html>