<html>

<head>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="sidenav" id="bar">

        <div class="back">
            <a href="em.php">
                <img class="notif" src="./img/Exam Maker (5) 6.png">
            </a>
        </div>

        <div class="help">
            <a href="#">
                <img class="notif" src="./img/Help.png">
            </a>
        </div>

    </div>
</body>

</html>