<?php
session_start();
require('database/connect.php');
if (!isset($_SESSION['account_id'])) {
    // Redirect to the login page if the user is not logged in
    echo '<script>alert("User is not logged in, directing to login page.")</script>';
    echo "<script> window.location.assign('login.php'); </script>";
    exit();
}


$account_id = $_SESSION['account_id'];


// Display the user-specific information
$sql = "SELECT * FROM account WHERE account_id = $account_id";
$result = mysqli_query($conn, $sql); // Replace with data from the database
if ($result) {
    $row = mysqli_fetch_array($result);
    $user_email = $row['user_email'];
    $pwd = $row['pwd'];
    $first_name = $row['first_name'];
    $last_name = $row['last_name'];
    $role = $row['role'];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="author" content="APC AcademX">
    <title>APC AcademX | Program List</title>
    <link rel="stylesheet" href="./css/adminstyle.css">
    <script src="https://kit.fontawesome.com/e85940e9f2.js" crossorigin="anonymous"></script>
</head>

<body>

    <?php include('topnavAdmin.php'); ?>


    <!-- body -->
    <div class="column">

        <div class="left">

            <?php include('sidenavAdmin.php'); ?>
            
        </div>

        <div class="mid">

            <div class="midnav">

                <div class="midhead">
                    <p> Settings </p>
                </div>

                <div class="line">
                </div>

                <div>
                    <a href="usersettings.html" class="midbutton">
                        <p> User Settings </p>
                    </a>
                </div>

                <div>
                    <a href="adminset.html" class="midbutton">
                        <p> Admin Settings </p>
                    </a>
                </div>

                <div>
                    <a href="programlist.html" class="midbutton active">
                        <p> Program List </p>
                    </a>
                </div>

            </div>


        </div>

        <div class="right">

            <div class="container">

                <div class="righthead">

                    <div class="adminicon">
                        <img lass="iconadmin" src="./img/user.png" width="70%">
                    </div>

                    <div class="programlisthead">
                        <p> Program List</p>
                    </div>

                    <div class="search">
                        <div>
                            <input type="text" class="searchbar">
                        </div>

                        <div class="searchicon">
                            <i class="fa-solid fa-magnifying-glass"></i>
                        </div>
                    </div>
                </div>

                <div class="adminline">
                </div>

                <div class="table">
                    <div class="tablecontent">

                        <div class="adminame">
                            <p>
                                Academic Program
                            </p>
                            <div class="adname">
                                <p> Computer Engineering </p>
                            </div>

                            <div class="ademail">
                                <p> (45 course files) </p>
                            </div>
                        </div>

                        <div class="adremove">
                            <a href="#"> Remove </a>
                        </div>
                    </div>

                    <div class="tablecontent">

                        <div class="adminame">
                            <p>
                                Academic Program
                            </p>
                            <div class="adname">
                                <p> Electronics Engineering </p>
                            </div>

                            <div class="ademail">
                                <p> (34 course files) </p>
                            </div>
                        </div>

                        <div class="adremove">
                            <a href="#"> Remove </a>
                        </div>
                    </div>

                    <div class="tablecontent">

                        <div class="adminame">
                            <p>
                                Academic Program
                            </p>
                            <div class="adname">
                                <p> Civil Engineering </p>
                            </div>

                            <div class="ademail">
                                <p> (7 course files) </p>
                            </div>
                        </div>

                        <div class="adremove">
                            <a href="#"> Remove </a>
                        </div>
                    </div>

                    <div class="tablecontent">

                        <div class="adminame">
                            <p>
                                Academic Program
                            </p>
                            <div class="adname">
                                <p> Architecture </p>
                            </div>

                            <div class="ademail">
                                <p> (0 course files) </p>
                            </div>
                        </div>

                        <div class="adremove">
                            <a href="#"> Remove </a>
                        </div>
                    </div>

                </div>

                <div class="info">
                    <div class="rolesinfo">
                        <a href="#"><i class="fa-solid fa-circle-info"></i> Roles Information </a>
                    </div>
                </div>

            </div>



        </div>

    </div>

</body>

</html>