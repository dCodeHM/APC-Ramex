<?php include('database/connect.php'); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="author" content="APC AcademX">
    <title>APC AcademX | Login</title>
    <link rel="stylesheet" href="./css/teststyle.css">

</head>

<body>

    <!-- <a href="index.html"><h1>LOGIN</h1></a> -->
    <div class="malakingboxsagitna">
        <form action="auth.php" method="post">
            <p class="header">
                LOGIN
            </p>
            <label for="user_email">Email</label>
            <input type="text" placeholder="Your Email" name="user_email" required><br />
            <label for="pwd">Password</label>
            <input type="pwd" placeholder="Your Password" name="pwd" required><br />
            <button type="submit">Login</button>
        </form>
    </div>

    <script src="" async defer></script>
</body>

</html>