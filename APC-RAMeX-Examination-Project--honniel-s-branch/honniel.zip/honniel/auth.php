<?php
session_start();
require('database/connect.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_email = $_POST['user_email'];
    $pwd = $_POST['pwd'];

    $sql = "SELECT * FROM account WHERE user_email = ? AND pwd = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $user_email, $pwd);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();

        $_SESSION["account_id"] = $row["account_id"];
        $_SESSION["user_email"] = $row["user_email"];
        $_SESSION["pwd"] = $row["pwd"];

        echo '<script>alert("Logged in as admin.")</script>';
        echo '<script>window.location.assign("index.php");</script>';
    } else {
        echo '<script>alert("Unknown email or password.")</script>';
        echo '<script>window.location.assign("login.php")</script>';
    }

    $stmt->close();
} else {
    echo "Invalid request!";
}
?>