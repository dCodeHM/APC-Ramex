<?php
    session_start();
    require('database/connect.php');
    if (!isset($_SESSION['account_id'])) {
        // Redirect to the login page if the user is not logged in
        echo '<script>alert("User is not logged in, directing to login page.")</script>';
        echo "<script> window.location.assign('login.php'); </script>";
        exit();
    }


    $account_id = $_SESSION['account_id'];


    // Display the user-specific information
    $sql = "SELECT * FROM account WHERE account_id = $account_id";
    $result = mysqli_query($conn, $sql); // Replace with data from the database
    if ($result) {
        $row = mysqli_fetch_array($result);
        $user_email = $row['user_email'];
        $pwd = $row['pwd'];
        $first_name = $row['first_name'];
        $last_name = $row['last_name'];
        $role = $row['role'];
    }

    require('topicfolder.php');
    ?>

    <?php
    // Retrieve the course code from the URL parameter
    $courseCode = isset($_GET['course_code']) ? $_GET['course_code'] : '';

    // Optionally, you may sanitize and validate the course code here

    // Set the course code as the header text
    $courseFolderName = $courseCode;
    ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width">
        <meta name="author" content="APC AcademX">
        <title>APC AcademX | Exam Maker</title>
        <link rel="stylesheet" href="./css/topicstyle.css">
        <link rel="stylesheet" href="./css/style.css">
        <link rel="stylesheet" href="./css/adminstyle.css">
        <link rel="stylesheet" href="./css/emstyle.css">
        <link rel="stylesheet" href="./css/myexamstyle.css">
        <script src="https://kit.fontawesome.com/e85940e9f2.js" crossorigin="anonymous"></script>

        <style>
            .heading {
                font-weight: bold;
                font-size: 15px;
                text-align: center;
            }

            .form {
                height: 30vh;
                background-color: #fff;
                border-radius: 10px;
                width: 100%;
                margin: auto;
                border: 1px solid black;
                box-shadow: #2d2d2d;
                padding: 15px;
            }

            .inputcolumn {
                display: flex;
            }

            .label {
                color: #334fec;
                font-size: 15px;
                width: 50%;
            }

            .input {
                border-radius: 10px;
                height: 35px;
                width: 100%;
            }

            .mahabangbox {
                border-radius: 8px;
                display: block;
                float: left;
                color: #848484;
                text-align: center;
                font: bolder;
                margin: auto;
                font-size: 25px;
                font-weight: bolder;
                padding: 25px;
            }

            .boxt {
                display: block;
                justify-content: left;
                align-items: center;
                width: 95%;
                float: left;
                padding: 9px;
                position: relative;
                margin: 1%;
                background-color: white;
                border-radius: 5px;
                box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
            }

            .boxt a {
                display: block;
                /* Make the anchor fill the entire box */
                width: 100%;
                /* Ensure full width for clickable area */
                height: 100%;
                /* Ensure full height for clickable area */
                text-decoration: none;
                /* Remove underline from anchor */
            }

            .popup_bg {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.5);
                /* Adjust the opacity to darken/lighten */
                z-index: 9999;
                /* Make sure the overlay is above everything else */
            }

            .Add_popup {
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                background-color: white;
                padding: 20px;
                border-radius: 5px;
                z-index: 10000;
                /* Make sure the popup is above the overlay */
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
                /* Add a shadow for depth */
            }

            .save {
                width: 200px;
                height: 55px;
                right: 1rem;
                bottom: 1rem;
                position: absolute;
                background: #343A40;
                color: #FFFFFF;
                text-decoration: bold;
                box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
                border-radius: 10px;
                cursor: pointer;

            }

            .save:hover {
                color: #334fec;
                background-color: #dfdfdf;
                border-radius: 10px;
            }

            .update {
                width: 200px;
                height: 55px;
                right: 1rem;
                bottom: 1rem;
                position: absolute;
                background: #343A40;
                color: #FFFFFF;
                text-decoration: bold;
                box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
                border-radius: 10px;
                cursor: pointer;
            }

            .update:hover {
                color: #334fec;
                background-color: #dfdfdf;
                border-radius: 10px;
            }

            .cancelbutton {
                width: 100%;
                text-align: center;
                text-decoration: none;

            }

            .cancel {
                width: 200px;
                height: 55px;
                right: 14rem;
                bottom: 1rem;
                position: absolute;
                background: #EDEDED;
                color: #343A40;
                text-decoration: bold;
                box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
                border-radius: 10px;
                cursor: pointer;
            }

            .cancel.hover {
                text-decoration: none;
                background: #EDEDED;
                color: #343A40;
                width: 100%;
            }
        </style>
    </head>

    <body>

        <?php include('topnavAdmin.php'); ?>

        <div class="column">

            <div class="left">

                <?php include('sidenavAdmin.php'); ?>
            </div>

            <!--header-->
            <div class="containerem">

                <div class="rightemhead">
                    <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                        <?php $courseFolderName = $row['courseFolderName']; ?>
                    <?php endwhile; ?>
                    <div class="adminmehead">
                        <p><?php echo $courseFolderName; ?></p>
                    </div>

                    <script src="./myexams.js"></script>
                    <div class="searchicon " style="position:relative; left: 45%">
                        <input type="text" class="searchbar">
                    </div>
                </div>
                <!--line-->
                <div class="adminemline">
                </div>


                <!--boxes-->

                <?php $result = $mysqli->query("SELECT * from prof_course_topic WHERE account_id = $account_id") or die(mysqli_error($mysqli));
                if ($result->num_rows === 0) { ?>

                    <p class="header">You have no topic folders.</p>

                <?php } else { ?>
                    <div style="display:block;">
                        <?php while ($row = $result->fetch_assoc()) : ?>
                            <section id="container2">
                                <div class="emservices">
                                    <div class="mebox">
                                        <div class="boxt"> 
                                            <a href="topic.php?course_topics=<?php echo urlencode($row['course_topics']); ?>" class="fill-div">
                                                <p class="mahabangbox">
                                                    <?php echo $row['course_topics']; ?>
                                                </p>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </section>
                    <?php endwhile;
                    }
                    ?>
                    </div>
            </div>
        </div>
    </body>
    <script>
        function showPopup() {
            // Select the popup element
            const popup = document.querySelector(".popup-hidden");
            // Remove the "hidden" class to display the popup
            popup.classList.remove("popup-hidden");
            // Prevent default link behavior
            return false;
        }

        function showEditPopup(course_topic_id, update) {
            const popup = document.querySelector(".popup-hidden");
            popup.classList.remove("popup-hidden");
            document.getElementById("action").value = "edit";
            document.querySelector("form").action = `topicfolder.php?edit=${course_topic_id}`;
            // Optionally, you can pre-fill form fields here
            // Set the value of the $update PHP variable based on the update parameter
            $update = update;
        }

        function handleAction(select) {
            if (select.value.startsWith('topicfolder.php?delete=')) {
                if (confirm('Are you sure you want to delete this topic folder?')) {
                    window.location = select.value;
                }
            } else if (select.value.startsWith('topic.php?edit=')) {
                const editUrl = select.value;
                const urlParams = new URLSearchParams(editUrl);
                const courseTopicId = urlParams.get('edit');
                const updateParam = urlParams.get('update');
                // Set $update variable based on the updateParam
                const update = updateParam === 'true';
                showEditPopup(courseTopicId, update);
            }
        }
    </script>

    </html>