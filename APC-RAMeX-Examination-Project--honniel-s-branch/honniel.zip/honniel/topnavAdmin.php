<html>

<head>
    <link rel="stylesheet" href="./css/nav.css">
</head>

<body>
    <header>
        <!-- nav -->
        <div class="container1">

            <div id="branding">
                <a href="index.php"><img src="./img/APC AcademX Logo.png"></a>
                <a href="sa.php"><img id="saheader" src="./img/Student Assessment Header.png"></a>
                <a href="ca.php"><img id="caheader" src="./img/Course Assessment Header.png"></a>
                <a href="em.php"><img id="emactive" src="./img/Exam Maker Active.png"></a>

                <!--
                        Sheesh
                    -->
            </div>

            <nav>
                <ul>
                    <li class="username">
                        <h3><?php echo $first_name; ?> <?php echo $last_name; ?></h3>
                    </li>

                    <li class="notification">
                        <a href="#"><img class="notif" src="./img/Notification.png"></a>
                        <ul class="dropdown">
                            <img src="./img/Notification Title.png">
                        </ul>
                    </li>

                    <li class="user">
                        <a href="#"><img src="./img/LOGO (2) 1.png"></a>
                        <ul class="dropdown">
                            <h3><?php echo $role; ?></h3>
                            <a href="usersettings.php" class="settings">
                                <li>Settings⚙️</li>
                            </a>
                            <a href="login.php" class="logout">
                                <li>Logout[➡</li>
                            </a>
                        </ul>
                    </li>
                </ul>
            </nav>

        </div>

    </header>
</body>

</html>