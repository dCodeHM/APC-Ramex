<?php
session_start();
require('database/connect.php');

$update = isset($_GET['update']) && $_GET['update'] === 'true';

if (!isset($_SESSION['account_id'])) {
    // Redirect to the login page if the user is not logged in
    echo '<script>alert("User is not logged in, directing to login page.")</script>';
    echo "<script> window.location.assign('login.php'); </script>";
    exit();
}


$account_id = $_SESSION['account_id'];


// Display the user-specific information
$sql = "SELECT * FROM account WHERE account_id = $account_id";
$result = mysqli_query($conn, $sql); // Replace with data from the database
if ($result) {
    $row = mysqli_fetch_array($result);
    $user_email = $row['user_email'];
    $pwd = $row['pwd'];
    $first_name = $row['first_name'];
    $last_name = $row['last_name'];
    $role = $row['role'];
}
// Assuming $course_code is the course folder name
if (isset($course_code)) {
    $_SESSION['course_folder_name'] = $course_code;
}
require('coursefolder.php');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="author" content="APC AcademX">
    <title>APC AcademX | Exam Maker</title>
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/adminstyle.css">
    <link rel="stylesheet" href="./css/emstyle.css">
    <link rel="stylesheet" href="./css/myexamstyle.css">
    <script src="https://kit.fontawesome.com/e85940e9f2.js" crossorigin="anonymous"></script>

    <style>
        .heading {
            font-weight: bold;
            font-size: 15px;
            text-align: center;
        }

        .form {
            height: 30vh;
            background-color: #fff;
            border-radius: 10px;
            width: 100%;
            margin: auto;
            border: 1px solid black;
            box-shadow: #2d2d2d;
            padding: 15px;
        }

        .inputcolumn {
            display: flex;
        }

        .label {
            color: #334fec;
            font-size: 15px;
            width: 50%;
        }

        .input {
            border-radius: 10px;
            height: 35px;
            width: 100%;
        }

        .malakingbox {
            border-radius: 8px;
            background-color: #2d2d2d;
            color: #fff;
            text-align: center;
            margin: auto;
            width: 75%;
            font-size: 25px;
            font-weight: bolder;
            padding: 25px;
            display: block;
            justify-content: center;
            align-items: center;
            float: left;
            position: relative;
            margin: 1%;
            border-radius: 5px;
            box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
        }

        .popup_bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            /* Adjust the opacity to darken/lighten */
            z-index: 9999;
            /* Make sure the overlay is above everything else */
        }

        .Add_popup {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            z-index: 10000;
            /* Make sure the popup is above the overlay */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
            /* Add a shadow for depth */
        }

        .save {
            width: 200px;
            height: 55px;
            right: 1rem;
            bottom: 1rem;
            position: absolute;
            background: #343A40;
            color: #FFFFFF;
            text-decoration: bold;
            box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
            border-radius: 10px;
            cursor: pointer;

        }

        .save:hover {
            color: #334fec;
            background-color: #dfdfdf;
            border-radius: 10px;
        }

        .update {
            width: 200px;
            height: 55px;
            right: 1rem;
            bottom: 1rem;
            position: absolute;
            background: #343A40;
            color: #FFFFFF;
            text-decoration: bold;
            box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
            border-radius: 10px;
            cursor: pointer;
        }

        .update:hover {
            color: #334fec;
            background-color: #dfdfdf;
            border-radius: 10px;
        }

        .cancelbutton {
            width: 100%;
            text-align: center;
            text-decoration: none;

        }

        .cancel {
            width: 200px;
            height: 55px;
            right: 14rem;
            bottom: 1rem;
            position: absolute;
            background: #EDEDED;
            color: #343A40;
            text-decoration: bold;
            box-shadow: 0px 4px 4px rgba(0, 0, 0, 0.25);
            border-radius: 10px;
            cursor: pointer;
        }

        .cancel.hover {
            text-decoration: none;
            background: #EDEDED;
            color: #343A40;
            width: 100%;
        }
    </style>
</head>

<body>

    <?php include('topnavAdmin.php'); ?>

    <div class="column">

        <div class="left">

            <?php include('sidenavAdmin.php'); ?>
        </div>

        <!--header-->
        <div class="containerem">

            <div class="rightemhead">

                <div class="adminmehead">
                    <p> Exam Library </p>
                </div>

            </div>
            <!--line-->
            <div class="adminemline">
            </div>


            <!--boxes-->

            <?php $result = $mysqli->query("SELECT * from prof_course_subject WHERE account_id = $account_id") or die(mysqli_error($mysqli));
            if ($result->num_rows === 0) { ?>

                <p class="header">You have no course folders.</p>

            <?php } else { ?>
                <div style="flex-wrap: wrap;">

                    <?php while ($row = $result->fetch_assoc()) : ?>
                        <section id="container2">
                            <div class="emservices">
                                <div class="mebox">
                                    <div class="boxme">
                                        <a href="#" class="fill-div">
                                            <img src="./img/Graph.png">
                                        </a>
                                        <a href="examlibtopic.php?course_code=<?php echo urlencode($row['course_code']); ?>" class="fill-div">
                                            <p class="malakingbox">
                                                <?php echo $row['course_code']; ?>
                                            </p>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </section>
                <?php endwhile;
                }
                ?>
                </div>
        </div>
    </div>
</body>

</html>